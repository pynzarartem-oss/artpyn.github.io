import { Card } from "@/app/components/ui/card";
import { Newspaper, Award, Users, BookOpen } from "lucide-react";

export function About() {
  const stats = [
    { icon: Newspaper, value: "10+", label: "Медиа-проектов" },
    { icon: Award, value: "7+", label: "Достижений" },
    { icon: Users, value: "3", label: "Роли в эфире" },
    { icon: BookOpen, value: "2024", label: "Начало карьеры" },
  ];

  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl md:text-4xl mb-12 text-center text-gray-900">
          О себе
        </h2>

        <div className="grid md:grid-cols-2 gap-12 mb-16">
          <div>
            <p className="text-gray-700 mb-4 leading-relaxed">
              Я начал свой путь в журналистике в 2024 году, став председателем совета 
              первичного отделения Движения Первых ГБОУ Школа №806. С тех пор моя 
              деятельность расширилась на множество медиа-проектов и направлений.
            </p>
            <p className="text-gray-700 mb-4 leading-relaxed">
              Сегодня я совмещаю роли корреспондента в "Новости Первых", диктора на 
              "Классное Радио" и "Спасибо, Первый", а также являюсь медиа-наставником 
              проекта "Первые Первым" и руководителем медиа отдела ШСК "РоСпорт".
            </p>
          </div>
          <div>
            <p className="text-gray-700 mb-4 leading-relaxed">
              Моя специализация — молодёжная журналистика и развитие медиа-компетенций. 
              Я работаю с региональным медиа-центром Москвы и окружным медиа-центром 
              "Команда ЗАО", помогая развивать медиа-грамотность молодёжи.
            </p>
            <p className="text-gray-700 leading-relaxed">
              Как эксперт федеральных конкурсов Движения Первых, я помогаю оценивать 
              проекты участников и делюсь своим опытом с начинающими журналистами. 
              Верю в силу медиа для позитивных изменений в обществе.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index} className="p-6 text-center hover:shadow-lg transition-shadow">
                <Icon className="w-8 h-8 mx-auto mb-4 text-gray-900" />
                <div className="text-3xl mb-2 text-gray-900">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}