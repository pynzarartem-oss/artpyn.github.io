
  # Journalist Media Website

  This is a code bundle for Journalist Media Website. The original project is available at https://www.figma.com/design/JHRXMue9uDLMBGuweFgwgg/Journalist-Media-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  